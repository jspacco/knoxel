
public class Knoxel
{
    public static void main(String[] args)
    {
        // change the dimensions if you'd like
        int width=10;
        int depth=10;
        int height=10;
        BlockType[][][] grid = new BlockType[width][depth][height];
        // TODO: Build an awesome 3D structure
        
        Examples.drawStairs2(grid);
        
    }
    
}
