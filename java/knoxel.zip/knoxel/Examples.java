
/**
 * Write a description of class Examples here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Examples
{
    public static void drawStairs(BlockType[][][] grid){
        for (int x=0; x<grid.length; x++){
            for (int z=0; z<grid[x].length; z++){
                for (int y=0; y<=z; y++){
                    grid[x][z][y] = BlockType.GRANITE;
                }
            }
        }
        BlockWriter.writeDrawingToFile(grid, "stairs1.json");
    }
    
    public static void drawStairs2(BlockType[][][] grid){
        for (int x=0; x<grid.length; x++){
            for (int z=0; z<grid[x].length; z++){
                grid[x][z][z] = BlockType.RED_WOOL;
            }
        }
        BlockWriter.writeDrawingToFile(grid, "stairs2.json");
    }
    
    public static void drawSkyscraper() {
        BlockType[][][] grid = new BlockType[8][6][40];
        for (int floor=0; floor<10; floor++){
            for (int x=0; x<grid.length; x++){
                for (int z=0; z<grid[x].length; z++){
                    grid[x][z][floor*4] = BlockType.IRON_BLOCK;
                    grid[x][z][floor*4 + 1] = BlockType.GLASS;
                    grid[x][z][floor*4 + 2] = BlockType.GLASS;
                    grid[x][z][floor*4 + 3] = BlockType.GLASS;
                }
            }
        }
        BlockWriter.writeDrawingToFile(grid, "sky1.json");
    }
    
}
